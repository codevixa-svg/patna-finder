(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,18840,e=>{"use strict";var t=e.i(43476),s=e.i(71645),a=e.i(5766),i=e.i(69532);let r=["Owner","Co-owner / Partner","Manager","Authorized employee","Other"],o={businessName:"",listingUrl:"",yourName:"",email:"",phone:"",role:r[0],proof:"",message:""};function l({form:e,errors:s,set:a,submitting:i}){let o=e=>`w-full px-4 py-3 rounded-xl border bg-white text-gray-900 placeholder-gray-400 transition ${s[e]?"border-red-400":"border-gray-200"}`;return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-5",children:[(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{htmlFor:"claim-business",className:"block text-sm font-semibold text-gray-700 mb-1.5",children:["Business Name ",(0,t.jsx)("span",{className:"text-red-500",children:"*"})]}),(0,t.jsx)("input",{id:"claim-business",type:"text",value:e.businessName,onChange:e=>a("businessName",e.target.value),placeholder:"e.g. Sharma Sweets, Boring Road",className:o("businessName")}),s.businessName&&(0,t.jsx)("p",{className:"text-xs text-red-500 mt-1",children:s.businessName})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{htmlFor:"claim-url",className:"block text-sm font-semibold text-gray-700 mb-1.5",children:["Listing URL ",(0,t.jsx)("span",{className:"text-gray-400 font-normal",children:"(if known)"})]}),(0,t.jsx)("input",{id:"claim-url",type:"text",value:e.listingUrl,onChange:e=>a("listingUrl",e.target.value),placeholder:"patnafinder.com/business/…",className:o("listingUrl")})]})]}),(0,t.jsxs)("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-5",children:[(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{htmlFor:"claim-name",className:"block text-sm font-semibold text-gray-700 mb-1.5",children:["Your Name ",(0,t.jsx)("span",{className:"text-red-500",children:"*"})]}),(0,t.jsx)("input",{id:"claim-name",type:"text",value:e.yourName,onChange:e=>a("yourName",e.target.value),placeholder:"Full name",className:o("yourName")}),s.yourName&&(0,t.jsx)("p",{className:"text-xs text-red-500 mt-1",children:s.yourName})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{htmlFor:"claim-role",className:"block text-sm font-semibold text-gray-700 mb-1.5",children:"Your Role"}),(0,t.jsx)("select",{id:"claim-role",value:e.role,onChange:e=>a("role",e.target.value),className:o("role"),children:r.map(e=>(0,t.jsx)("option",{value:e,children:e},e))})]})]}),(0,t.jsxs)("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-5",children:[(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{htmlFor:"claim-email",className:"block text-sm font-semibold text-gray-700 mb-1.5",children:["Email Address ",(0,t.jsx)("span",{className:"text-red-500",children:"*"})]}),(0,t.jsx)("input",{id:"claim-email",type:"email",value:e.email,onChange:e=>a("email",e.target.value),placeholder:"you@business.com",className:o("email")}),s.email&&(0,t.jsx)("p",{className:"text-xs text-red-500 mt-1",children:s.email})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{htmlFor:"claim-phone",className:"block text-sm font-semibold text-gray-700 mb-1.5",children:["Business Phone ",(0,t.jsx)("span",{className:"text-red-500",children:"*"})]}),(0,t.jsx)("input",{id:"claim-phone",type:"tel",value:e.phone,onChange:e=>a("phone",e.target.value),placeholder:"+91 98XXX XXXXX",className:o("phone")}),s.phone&&(0,t.jsx)("p",{className:"text-xs text-red-500 mt-1",children:s.phone})]})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{htmlFor:"claim-proof",className:"block text-sm font-semibold text-gray-700 mb-1.5",children:["Ownership Proof ",(0,t.jsx)("span",{className:"text-gray-400 font-normal",children:"(optional)"})]}),(0,t.jsx)("input",{id:"claim-proof",type:"text",value:e.proof,onChange:e=>a("proof",e.target.value),placeholder:"GST number, shop licence, Google Business link…",className:o("proof")})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("label",{htmlFor:"claim-message",className:"block text-sm font-semibold text-gray-700 mb-1.5",children:["Anything Else? ",(0,t.jsx)("span",{className:"text-gray-400 font-normal",children:"(optional)"})]}),(0,t.jsx)("textarea",{id:"claim-message",rows:4,value:e.message,onChange:e=>a("message",e.target.value),placeholder:"Anything that helps us verify your claim faster…",className:`${o("message")} resize-y`})]}),(0,t.jsx)("button",{type:"submit",disabled:i,className:"w-full sm:w-auto bg-[#F4B400] text-gray-900 px-8 py-3.5 rounded-xl font-bold hover:bg-[#D89E00] transition shadow-md disabled:opacity-60 disabled:cursor-not-allowed",children:i?"Submitting…":"Submit Claim Request"})]})}e.s(["default",0,function(){let[e,r]=(0,s.useState)(o),[n,d]=(0,s.useState)({}),[c,m]=(0,s.useState)(!1),[u,p]=(0,s.useState)(!1),h=async t=>{let s;if(t.preventDefault(),s={},e.businessName.trim()||(s.businessName="Please enter the business name"),e.yourName.trim()||(s.yourName="Please enter your name"),/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.email.trim())||(s.email="Please enter a valid email address"),/^[+\d][\d\s-]{6,14}$/.test(e.phone.trim())||(s.phone="Please enter a valid phone number"),d(s),0===Object.keys(s).length){m(!0);try{let{via:t}=await (0,i.submitInquiry)("Claim Business",{Business:e.businessName,"Listing URL":e.listingUrl||"Not provided","Your Name":e.yourName,Email:e.email,Phone:e.phone,Role:e.role,"Ownership Proof":e.proof||"Will be shared on request",Notes:e.message||"—"});p(!0),a.default.success("mailto"===t?"Opening your email app with the claim pre-filled…":"Claim request submitted successfully!")}catch{a.default.error("Something went wrong. Please try again.")}finally{m(!1)}}};return u?(0,t.jsxs)("div",{className:"text-center py-10",children:[(0,t.jsx)("div",{className:"w-16 h-16 bg-[#FFF4CC] rounded-full flex items-center justify-center mx-auto mb-5",children:(0,t.jsx)("svg",{className:"w-8 h-8 text-[#062B49]",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",strokeWidth:2,children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"m5 12 4 4L19 6"})})}),(0,t.jsx)("h3",{className:"text-2xl font-bold text-gray-900 mb-2",children:"Claim Request Received!"}),(0,t.jsx)("p",{className:"text-gray-600 max-w-md mx-auto mb-6",children:"Our team will verify your ownership and reach out within 1–2 business days."}),(0,t.jsx)("button",{onClick:()=>{p(!1),r(o)},className:"text-[#B58200] font-semibold hover:text-[#8A6400] transition",children:"Submit another claim"})]}):(0,t.jsx)("form",{onSubmit:h,noValidate:!0,className:"space-y-5",children:(0,t.jsx)(l,{form:e,errors:n,set:(e,t)=>{r(s=>({...s,[e]:t})),d(t=>({...t,[e]:""}))},submitting:c})})}])},69532,e=>{"use strict";async function t(e,t){let s=Object.entries(t).map(([e,t])=>`${e}: ${t}`).join("\n");try{if((await fetch("http://localhost:8000/api/v1/inquiries",{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify({topic:e,...t})})).ok)return{via:"api"}}catch{}let a=encodeURIComponent(`[${e}] Patna Finder inquiry`);return window.location.href=`mailto:hello@patnafinder.com?subject=${a}&body=${encodeURIComponent(s)}`,{via:"mailto"}}e.i(47167),e.s(["submitInquiry",0,t])},5766,e=>{"use strict";let t,s;var a,i=e.i(71645);let r={data:""},o=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,l=/\/\*[^]*?\*\/|  +/g,n=/\n+/g,d=(e,t)=>{let s="",a="",i="";for(let r in e){let o=e[r];"@"==r[0]?"i"==r[1]?s=r+" "+o+";":a+="f"==r[1]?d(o,r):r+"{"+d(o,"k"==r[1]?"":t)+"}":"object"==typeof o?a+=d(o,t?t.replace(/([^,])+/g,e=>r.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):r):null!=o&&(r="-"==r[1]?r:r.replace(/[A-Z]/g,"-$&").toLowerCase(),i+=d.p?d.p(r,o):r+":"+o+";")}return s+(t&&i?t+"{"+i+"}":i)+a},c={},m=e=>{if("object"==typeof e){let t="";for(let s in e)t+=s+m(e[s]);return t}return e};function u(e){let t,s,a=this||{},i=e.call?e(a.p):e;return((e,t,s,a,i)=>{var r;let u=m(e),p=c[u]||(c[u]=(e=>{let t=0,s=11;for(;t<e.length;)s=101*s+e.charCodeAt(t++)>>>0;return"go"+s})(u));if(!c[p]){let t=u!==e?e:(e=>{let t,s,a=[{}];for(;t=o.exec(e.replace(l,""));)t[4]?a.shift():t[3]?(s=t[3].replace(n," ").trim(),a.unshift(a[0][s]=a[0][s]||{})):a[0][t[1]]=t[2].replace(n," ").trim();return a[0]})(e);c[p]=d(i?{["@keyframes "+p]:t}:t,s?"":"."+p)}let h=s&&c.g;return s&&(c.g=c[p]),r=c[p],h?t.data=t.data.replace(h,r):-1===t.data.indexOf(r)&&(t.data=a?r+t.data:t.data+r),p})(i.unshift?i.raw?(t=[].slice.call(arguments,1),s=a.p,i.reduce((e,a,i)=>{let r=t[i];if(r&&r.call){let e=r(s),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;r=t?"."+t:e&&"object"==typeof e?e.props?"":d(e,""):!1===e?"":e}return e+a+(null==r?"":r)},"")):i.reduce((e,t)=>Object.assign(e,t&&t.call?t(a.p):t),{}):i,(e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||r})(a.target),a.g,a.o,a.k)}u.bind({g:1});let p,h,f,g=u.bind({k:1});function b(e,t){let s=this||{};return function(){let a=arguments;function i(r,o){let l=Object.assign({},r),n=l.className||i.className;s.p=Object.assign({theme:h&&h()},l),s.o=/go\d/.test(n),l.className=u.apply(s,a)+(n?" "+n:""),t&&(l.ref=o);let d=e;return e[0]&&(d=l.as||e,delete l.as),f&&d[0]&&f(l),p(d,l)}return t?t(i):i}}var x=(e,t)=>"function"==typeof e?e(t):e,y=(t=0,()=>(++t).toString()),v=()=>{if(void 0===s&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");s=!e||e.matches}return s},N="default",j=(e,t)=>{let{toastLimit:s}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,s)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return j(e,{type:+!!e.toasts.find(e=>e.id===a.id),toast:a});case 3:let{toastId:i}=t;return{...e,toasts:e.toasts.map(e=>e.id===i||void 0===i?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let r=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+r}))}}},w=[],k={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},C={},E=(e,t=N)=>{C[t]=j(C[t]||k,e),w.forEach(([e,s])=>{e===t&&s(C[t])})},$=e=>Object.keys(C).forEach(t=>E(e,t)),O=(e=N)=>t=>{E(t,e)},P={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},F=e=>(t,s)=>{let a,i=((e,t="blank",s)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...s,id:(null==s?void 0:s.id)||y()}))(t,e,s);return O(i.toasterId||(a=i.id,Object.keys(C).find(e=>C[e].toasts.some(e=>e.id===a))))({type:2,toast:i}),i.id},S=(e,t)=>F("blank")(e,t);S.error=F("error"),S.success=F("success"),S.loading=F("loading"),S.custom=F("custom"),S.dismiss=(e,t)=>{let s={type:3,toastId:e};t?O(t)(s):$(s)},S.dismissAll=e=>S.dismiss(void 0,e),S.remove=(e,t)=>{let s={type:4,toastId:e};t?O(t)(s):$(s)},S.removeAll=e=>S.remove(void 0,e),S.promise=(e,t,s)=>{let a=S.loading(t.loading,{...s,...null==s?void 0:s.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let i=t.success?x(t.success,e):void 0;return i?S.success(i,{id:a,...s,...null==s?void 0:s.success}):S.dismiss(a),e}).catch(e=>{let i=t.error?x(t.error,e):void 0;i?S.error(i,{id:a,...s,...null==s?void 0:s.error}):S.dismiss(a)}),e};var A=1e3,D=g`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,I=g`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,R=g`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,T=b("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${D} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${I} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${R} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,B=g`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,L=b("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${B} 1s linear infinite;
`,U=g`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,z=g`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,q=b("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${U} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${z} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,X=b("div")`
  position: absolute;
`,M=b("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,_=g`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,H=b("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${_} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,Y=({toast:e})=>{let{icon:t,type:s,iconTheme:a}=e;return void 0!==t?"string"==typeof t?i.createElement(H,null,t):t:"blank"===s?null:i.createElement(M,null,i.createElement(L,{...a}),"loading"!==s&&i.createElement(X,null,"error"===s?i.createElement(T,{...a}):i.createElement(q,{...a})))},G=b("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,K=b("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,W=i.memo(({toast:e,position:t,style:s,children:a})=>{let r=e.height?((e,t)=>{let s=e.includes("top")?1:-1,[a,i]=v()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*s}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*s}%,-1px) scale(.6); opacity:0;}
`];return{animation:t?`${g(a)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${g(i)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||t||"top-center",e.visible):{opacity:0},o=i.createElement(Y,{toast:e}),l=i.createElement(K,{...e.ariaProps},x(e.message,e));return i.createElement(G,{className:e.className,style:{...r,...s,...e.style}},"function"==typeof a?a({icon:o,message:l}):i.createElement(i.Fragment,null,o,l))});a=i.createElement,d.p=void 0,p=a,h=void 0,f=void 0;var J=({id:e,className:t,style:s,onHeightUpdate:a,children:r})=>{let o=i.useCallback(t=>{if(t){let s=()=>{a(e,t.getBoundingClientRect().height)};s(),new MutationObserver(s).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,a]);return i.createElement("div",{ref:o,className:t,style:s},r)},V=u`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;e.s(["Toaster",0,({reverseOrder:e,position:t="top-center",toastOptions:s,gutter:a,children:r,toasterId:o,containerStyle:l,containerClassName:n})=>{let{toasts:d,handlers:c}=((e,t="default")=>{let{toasts:s,pausedAt:a}=((e={},t=N)=>{let[s,a]=(0,i.useState)(C[t]||k),r=(0,i.useRef)(C[t]);(0,i.useEffect)(()=>(r.current!==C[t]&&a(C[t]),w.push([t,a]),()=>{let e=w.findIndex(([e])=>e===t);e>-1&&w.splice(e,1)}),[t]);let o=s.toasts.map(t=>{var s,a,i;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(s=e[t.type])?void 0:s.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(a=e[t.type])?void 0:a.duration)||(null==e?void 0:e.duration)||P[t.type],style:{...e.style,...null==(i=e[t.type])?void 0:i.style,...t.style}}});return{...s,toasts:o}})(e,t),r=(0,i.useRef)(new Map).current,o=(0,i.useCallback)((e,t=A)=>{if(r.has(e))return;let s=setTimeout(()=>{r.delete(e),l({type:4,toastId:e})},t);r.set(e,s)},[]);(0,i.useEffect)(()=>{if(a)return;let e=Date.now(),i=s.map(s=>{if(s.duration===1/0)return;let a=(s.duration||0)+s.pauseDuration-(e-s.createdAt);if(a<0){s.visible&&S.dismiss(s.id);return}return setTimeout(()=>S.dismiss(s.id,t),a)});return()=>{i.forEach(e=>e&&clearTimeout(e))}},[s,a,t]);let l=(0,i.useCallback)(O(t),[t]),n=(0,i.useCallback)(()=>{l({type:5,time:Date.now()})},[l]),d=(0,i.useCallback)((e,t)=>{l({type:1,toast:{id:e,height:t}})},[l]),c=(0,i.useCallback)(()=>{a&&l({type:6,time:Date.now()})},[a,l]),m=(0,i.useCallback)((e,t)=>{let{reverseOrder:a=!1,gutter:i=8,defaultPosition:r}=t||{},o=s.filter(t=>(t.position||r)===(e.position||r)&&t.height),l=o.findIndex(t=>t.id===e.id),n=o.filter((e,t)=>t<l&&e.visible).length;return o.filter(e=>e.visible).slice(...a?[n+1]:[0,n]).reduce((e,t)=>e+(t.height||0)+i,0)},[s]);return(0,i.useEffect)(()=>{s.forEach(e=>{if(e.dismissed)o(e.id,e.removeDelay);else{let t=r.get(e.id);t&&(clearTimeout(t),r.delete(e.id))}})},[s,o]),{toasts:s,handlers:{updateHeight:d,startPause:n,endPause:c,calculateOffset:m}}})(s,o);return i.createElement("div",{"data-rht-toaster":o||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...l},className:n,onMouseEnter:c.startPause,onMouseLeave:c.endPause},d.map(s=>{let o,l,n=s.position||t,d=c.calculateOffset(s,{reverseOrder:e,gutter:a,defaultPosition:t}),m=(o=n.includes("top"),l=n.includes("center")?{justifyContent:"center"}:n.includes("right")?{justifyContent:"flex-end"}:{},{left:0,right:0,display:"flex",position:"absolute",transition:v()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${d*(o?1:-1)}px)`,...o?{top:0}:{bottom:0},...l});return i.createElement(J,{id:s.id,key:s.id,onHeightUpdate:c.updateHeight,className:s.visible?V:"",style:m},"custom"===s.type?x(s.message,s):r?r(s):i.createElement(W,{toast:s,position:n}))}))},"default",0,S],5766)}]);