(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,18048,e=>{"use strict";var t=e.i(43476),a=e.i(71645),s=e.i(18566),r=e.i(22016),i=e.i(5766),o=e.i(51349),n=e.i(62476);let l=[{value:"gst",label:"GST Certificate"},{value:"fssai",label:"FSSAI License (food business)"},{value:"trade_license",label:"Trade License"},{value:"id_proof",label:"Owner ID Proof (Aadhaar/PAN)"},{value:"signboard_photo",label:"Signboard Photo"},{value:"address_proof",label:"Address Proof (bill/agreement)"},{value:"medical_registration",label:"Medical Registration"},{value:"other",label:"Other"}];e.s(["default",0,function(){let e=(0,s.useParams)().id,{isAuthenticated:d}=(0,o.useUserAuthStore)(),[c,u]=(0,a.useState)(null),[p,m]=(0,a.useState)(!0),[f,g]=(0,a.useState)(""),[y,b]=(0,a.useState)(null),[h,x]=(0,a.useState)(""),[v,w]=(0,a.useState)(!1);async function j(){try{let t=await n.userVerificationApi.getStatus(Number(e));u(t)}catch(e){i.default.error(e.message||"Failed to load")}finally{m(!1)}}async function N(){if(!f)return void i.default.error("Document type select karein");if(!y)return void i.default.error("File select karein");let t=new FormData;t.append("doc_type",f),t.append("file",y),h&&t.append("expires_at",h);try{w(!0),await n.userVerificationApi.uploadDocument(Number(e),t),i.default.success("Document uploaded! Team review karegi."),g(""),b(null),x(""),j()}catch(e){i.default.error(e?.response?.data?.message||e.message||"Upload failed")}finally{w(!1)}}async function k(t){if(confirm("Delete this document?"))try{await n.userVerificationApi.deleteDocument(Number(e),t),i.default.success("Deleted"),j()}catch(e){i.default.error(e?.response?.data?.message||e.message||"Failed")}}async function A(){try{w(!0);let t=await n.userVerificationApi.requestVerification(Number(e));i.default.success(t.message||"Request submitted!"),j()}catch(e){i.default.error(e?.response?.data?.message||e.message||"Failed")}finally{w(!1)}}if((0,a.useEffect)(()=>{if(!d){window.location.href="/dashboard/login";return}j()},[d,e]),!d)return null;if(p)return(0,t.jsx)("div",{className:"min-h-screen bg-gray-50 flex items-center justify-center",children:(0,t.jsx)("div",{className:"animate-spin rounded-full h-10 w-10 border-b-2 border-[#D89E00]"})});let D=c?.is_verified,_=!!c?.verification_requested_at,$=c?.required_docs||[],C=c?.documents||[];return(0,t.jsx)("div",{className:"min-h-screen bg-gray-50 py-8 px-4",children:(0,t.jsxs)("div",{className:"max-w-3xl mx-auto space-y-6",children:[(0,t.jsx)(r.default,{href:"/dashboard/businesses",className:"text-[#B58200] hover:text-[#8A6400] text-sm font-medium inline-flex items-center gap-1",children:"← Back to My Businesses"}),(0,t.jsxs)("div",{className:"bg-white rounded-2xl border border-gray-100 p-6",children:[(0,t.jsx)("h1",{className:"text-xl font-bold text-gray-900 mb-2",children:"Get Verified by Patna Finder"}),D?(0,t.jsxs)("div",{className:"flex items-center gap-2 p-3 bg-[#FFF9E5] border border-green-200 rounded-lg",children:[(0,t.jsx)("span",{className:"text-2xl",children:"✓"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{className:"text-sm font-bold text-[#062B49]",children:"Your business is Verified!"}),(0,t.jsx)("p",{className:"text-xs text-[#062B49]",children:"Verified badge public profile par dikh raha hai."})]})]}):_?(0,t.jsxs)("div",{className:"flex items-center justify-between p-3 bg-yellow-50 border border-yellow-200 rounded-lg",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{className:"text-sm font-bold text-yellow-800",children:"Verification Request Pending"}),(0,t.jsx)("p",{className:"text-xs text-yellow-700",children:"Team jaldi hi aapke documents review karke contact karegi."})]}),(0,t.jsx)("button",{onClick:async()=>{await n.userVerificationApi.cancelRequest(Number(e)),i.default.success("Request cancelled"),j()},className:"text-xs text-gray-500 hover:text-red-600 underline",children:"Cancel"})]}):(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{className:"text-sm text-gray-600 mb-3",children:"Verified badge se customers ka trust badhta hai. Documents upload karein aur request bhejein — team aapke business ko review karke (address visit / Google details check) verify karegi."}),(0,t.jsx)("button",{onClick:A,disabled:v,className:"px-5 py-2.5 bg-[#D89E00] text-white rounded-xl text-sm font-bold hover:bg-[#B58200] disabled:opacity-50 transition",children:"✓ Request Verification"})]})]}),$.length>0&&!D&&(0,t.jsxs)("div",{className:"bg-white rounded-2xl border border-gray-100 p-6",children:[(0,t.jsx)("h2",{className:"text-sm font-bold text-gray-900 mb-3",children:"Aapki category ke liye required documents:"}),(0,t.jsx)("div",{className:"flex flex-wrap gap-2",children:$.map(e=>{let a=C.find(t=>t.doc_type===e&&"approved"===t.status),s=C.find(t=>t.doc_type===e);return(0,t.jsxs)("span",{className:`px-3 py-1.5 rounded-full text-xs font-medium border ${a?"bg-[#FFF9E5] text-[#062B49] border-green-200":s?"bg-yellow-50 text-yellow-700 border-yellow-200":"bg-gray-50 text-gray-600 border-gray-200"}`,children:[a?"✓ Approved":s?"⏳ Under review":"○ Pending"," — ",e.replace(/_/g," ")]},e)})})]}),!D&&(0,t.jsxs)("div",{className:"bg-white rounded-2xl border border-gray-100 p-6",children:[(0,t.jsx)("h2",{className:"text-sm font-bold text-gray-900 mb-4",children:"Upload Documents"}),(0,t.jsxs)("div",{className:"space-y-3",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-xs font-medium text-gray-600 mb-1",children:"Document Type *"}),(0,t.jsxs)("select",{value:f,onChange:e=>g(e.target.value),className:"w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#D89E00]",children:[(0,t.jsx)("option",{value:"",children:"Select..."}),l.map(e=>(0,t.jsx)("option",{value:e.value,children:e.label},e.value))]})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-xs font-medium text-gray-600 mb-1",children:"File (PDF/JPG/PNG, max 5MB) *"}),(0,t.jsx)("input",{type:"file",accept:".pdf,.jpg,.jpeg,.png,.webp",onChange:e=>b(e.target.files?.[0]||null),className:"text-sm"})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-xs font-medium text-gray-600 mb-1",children:"Valid Till (license expiry, optional)"}),(0,t.jsx)("input",{type:"date",value:h,onChange:e=>x(e.target.value),className:"w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"})]}),(0,t.jsx)("button",{onClick:N,disabled:v,className:"w-full py-2.5 bg-[#D89E00] text-white rounded-xl text-sm font-bold hover:bg-[#B58200] disabled:opacity-50 transition",children:v?"Uploading...":"Upload Document"}),(0,t.jsx)("p",{className:"text-[11px] text-gray-400",children:"Documents securely store hote hain — sirf Patna Finder team dekh sakti hai."})]})]}),C.length>0&&(0,t.jsxs)("div",{className:"bg-white rounded-2xl border border-gray-100 p-6",children:[(0,t.jsx)("h2",{className:"text-sm font-bold text-gray-900 mb-4",children:"My Documents"}),(0,t.jsx)("div",{className:"space-y-3",children:C.map(e=>(0,t.jsxs)("div",{className:"flex items-center gap-3 p-3 border border-gray-100 rounded-lg",children:[(0,t.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,t.jsxs)("p",{className:"text-sm font-semibold text-gray-900",children:[e.doc_type_label,(0,t.jsx)("span",{className:`ml-2 px-2 py-0.5 rounded-full text-[10px] font-bold ${"approved"===e.status?"bg-[#FFF4CC] text-[#062B49]":"rejected"===e.status?"bg-red-100 text-red-700":"bg-yellow-100 text-yellow-700"}`,children:e.status.toUpperCase()})]}),(0,t.jsxs)("p",{className:"text-xs text-gray-500 mt-0.5",children:[e.original_name,e.expires_at&&(0,t.jsxs)(t.Fragment,{children:[" • Valid till ",e.expires_at]})]}),e.review_note&&(0,t.jsxs)("p",{className:"text-xs text-gray-600 mt-1 italic",children:["Team note: ",e.review_note]})]}),"pending"===e.status&&(0,t.jsx)("button",{onClick:()=>k(e.id),className:"text-xs text-gray-400 hover:text-red-600 underline",children:"Delete"})]},e.id))})]})]})})}])},62476,e=>{"use strict";e.i(47167);let t=e.i(81949).default.create({baseURL:"http://localhost:8000/api/v1",headers:{"Content-Type":"application/json",Accept:"application/json"}});t.interceptors.request.use(e=>{let t=localStorage.getItem("user-auth-storage");if(t){let{state:a}=JSON.parse(t);a?.token&&(e.headers.Authorization=`Bearer ${a.token}`)}return e},e=>Promise.reject(e)),t.interceptors.response.use(e=>e,e=>(e.response?.status===401&&(localStorage.removeItem("user-auth-storage"),window.location.href="/dashboard/login"),Promise.reject(e))),e.s(["userAuthApi",0,{register:async(e,a,s,r,i)=>(await t.post("/user/register",{name:e,email:a,password:s,password_confirmation:r,phone:i})).data,login:async(e,a)=>(await t.post("/user/login",{email:e,password:a})).data,verifyMfa:async(e,a)=>(await t.post("/user/verify-mfa",{challenge_token:e,code:a})).data,resendMfa:async e=>(await t.post("/user/resend-mfa",{challenge_token:e})).data,loginWithOtp:async e=>(await t.post("/user/login-with-otp",{email:e})).data,verifyOtp:async(e,a)=>(await t.post("/user/verify-otp",{challenge_token:e,code:a})).data,resendOtp:async e=>(await t.post("/user/resend-otp",{challenge_token:e})).data,logout:async()=>(await t.post("/user/logout")).data,logoutAll:async()=>(await t.post("/user/logout-all")).data,me:async()=>(await t.get("/user/me")).data,changePassword:async(e,a,s)=>(await t.post("/user/change-password",{current_password:e,new_password:a,new_password_confirmation:s})).data,securityOverview:async()=>(await t.get("/user/security")).data,toggleMfa:async e=>(await t.post("/user/security/mfa",{enabled:e})).data,updateProfile:async e=>(await t.put("/user/profile",e)).data},"userBusinessApi",0,{getAll:async()=>(await t.get("/user/businesses")).data,getOne:async e=>(await t.get(`/user/businesses/${e}`)).data,create:async e=>(await t.post("/user/businesses",e)).data,update:async(e,a)=>(await t.put(`/user/businesses/${e}`,a)).data,delete:async e=>(await t.delete(`/user/businesses/${e}`)).data,saveDraft:async e=>(await t.post("/user/businesses/draft",e)).data,uploadImageBase64:async(e,a)=>(await t.post("/user/upload-image-base64",{image:e,type:a})).data,deleteImage:async e=>(await t.post("/user/delete-image",{path:e})).data},"userDashboardApi",0,{getStats:async()=>(await t.get("/user/dashboard")).data,getQuickStats:async()=>(await t.get("/user/dashboard/quick-stats")).data,getAnalytics:async e=>(await t.get("/user/analytics",{params:e})).data},"userSubscriptionApi",0,{createOrder:async e=>(await t.post("/user/subscription/create-order",{plan:e})).data,verifyPayment:async(e,a,s)=>(await t.post("/user/subscription/verify",{razorpay_order_id:e,razorpay_payment_id:a,razorpay_signature:s})).data,getCurrentPlan:async()=>(await t.get("/user/subscription/current")).data,cancel:async()=>(await t.post("/user/subscription/cancel")).data,getHistory:async()=>(await t.get("/user/subscription/history")).data},"userUpdateApi",0,{getAll:async()=>(await t.get("/user/updates")).data,getOne:async e=>(await t.get(`/user/updates/${e}`)).data,create:async e=>(await t.post("/user/updates",e)).data,update:async(e,a)=>(await t.put(`/user/updates/${e}`,a)).data,delete:async e=>(await t.delete(`/user/updates/${e}`)).data,toggleActive:async e=>(await t.post(`/user/updates/${e}/toggle-active`)).data,uploadImage:async e=>(await t.post("/user/upload-image-base64",{image:e,type:"update"})).data},"userVerificationApi",0,{getStatus:async e=>(await t.get(`/user/businesses/${e}/verification`)).data,uploadDocument:async(e,a)=>(await t.post(`/user/businesses/${e}/verification/documents`,a,{headers:{"Content-Type":"multipart/form-data"}})).data,deleteDocument:async(e,a)=>(await t.delete(`/user/businesses/${e}/verification/documents/${a}`)).data,requestVerification:async e=>(await t.post(`/user/businesses/${e}/verification/request`)).data,cancelRequest:async e=>(await t.post(`/user/businesses/${e}/verification/cancel-request`)).data}])},5766,e=>{"use strict";let t,a;var s,r=e.i(71645);let i={data:""},o=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,n=/\/\*[^]*?\*\/|  +/g,l=/\n+/g,d=(e,t)=>{let a="",s="",r="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?a=i+" "+o+";":s+="f"==i[1]?d(o,i):i+"{"+d(o,"k"==i[1]?"":t)+"}":"object"==typeof o?s+=d(o,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i="-"==i[1]?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),r+=d.p?d.p(i,o):i+":"+o+";")}return a+(t&&r?t+"{"+r+"}":r)+s},c={},u=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+u(e[a]);return t}return e};function p(e){let t,a,s=this||{},r=e.call?e(s.p):e;return((e,t,a,s,r)=>{var i;let p=u(e),m=c[p]||(c[p]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(p));if(!c[m]){let t=p!==e?e:(e=>{let t,a,s=[{}];for(;t=o.exec(e.replace(n,""));)t[4]?s.shift():t[3]?(a=t[3].replace(l," ").trim(),s.unshift(s[0][a]=s[0][a]||{})):s[0][t[1]]=t[2].replace(l," ").trim();return s[0]})(e);c[m]=d(r?{["@keyframes "+m]:t}:t,a?"":"."+m)}let f=a&&c.g;return a&&(c.g=c[m]),i=c[m],f?t.data=t.data.replace(f,i):-1===t.data.indexOf(i)&&(t.data=s?i+t.data:t.data+i),m})(r.unshift?r.raw?(t=[].slice.call(arguments,1),a=s.p,r.reduce((e,s,r)=>{let i=t[r];if(i&&i.call){let e=i(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":d(e,""):!1===e?"":e}return e+s+(null==i?"":i)},"")):r.reduce((e,t)=>Object.assign(e,t&&t.call?t(s.p):t),{}):r,(e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||i})(s.target),s.g,s.o,s.k)}p.bind({g:1});let m,f,g,y=p.bind({k:1});function b(e,t){let a=this||{};return function(){let s=arguments;function r(i,o){let n=Object.assign({},i),l=n.className||r.className;a.p=Object.assign({theme:f&&f()},n),a.o=/go\d/.test(l),n.className=p.apply(a,s)+(l?" "+l:""),t&&(n.ref=o);let d=e;return e[0]&&(d=n.as||e,delete n.as),g&&d[0]&&g(n),m(d,n)}return t?t(r):r}}var h=(e,t)=>"function"==typeof e?e(t):e,x=(t=0,()=>(++t).toString()),v=()=>{if(void 0===a&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");a=!e||e.matches}return a},w="default",j=(e,t)=>{let{toastLimit:a}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,a)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:s}=t;return j(e,{type:+!!e.toasts.find(e=>e.id===s.id),toast:s});case 3:let{toastId:r}=t;return{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},N=[],k={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},A={},D=(e,t=w)=>{A[t]=j(A[t]||k,e),N.forEach(([e,a])=>{e===t&&a(A[t])})},_=e=>Object.keys(A).forEach(t=>D(e,t)),$=(e=w)=>t=>{D(t,e)},C={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},E=e=>(t,a)=>{let s,r=((e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||x()}))(t,e,a);return $(r.toasterId||(s=r.id,Object.keys(A).find(e=>A[e].toasts.some(e=>e.id===s))))({type:2,toast:r}),r.id},P=(e,t)=>E("blank")(e,t);P.error=E("error"),P.success=E("success"),P.loading=E("loading"),P.custom=E("custom"),P.dismiss=(e,t)=>{let a={type:3,toastId:e};t?$(t)(a):_(a)},P.dismissAll=e=>P.dismiss(void 0,e),P.remove=(e,t)=>{let a={type:4,toastId:e};t?$(t)(a):_(a)},P.removeAll=e=>P.remove(void 0,e),P.promise=(e,t,a)=>{let s=P.loading(t.loading,{...a,...null==a?void 0:a.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let r=t.success?h(t.success,e):void 0;return r?P.success(r,{id:s,...a,...null==a?void 0:a.success}):P.dismiss(s),e}).catch(e=>{let r=t.error?h(t.error,e):void 0;r?P.error(r,{id:s,...a,...null==a?void 0:a.error}):P.dismiss(s)}),e};var O=1e3,S=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,F=y`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,T=y`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,I=b("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${S} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${F} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${T} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,q=y`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,B=b("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${q} 1s linear infinite;
`,V=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,M=y`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,R=b("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${V} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${M} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,U=b("div")`
  position: absolute;
`,z=b("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,L=y`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,H=b("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${L} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,G=({toast:e})=>{let{icon:t,type:a,iconTheme:s}=e;return void 0!==t?"string"==typeof t?r.createElement(H,null,t):t:"blank"===a?null:r.createElement(z,null,r.createElement(B,{...s}),"loading"!==a&&r.createElement(U,null,"error"===a?r.createElement(I,{...s}):r.createElement(R,{...s})))},J=b("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,K=b("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Y=r.memo(({toast:e,position:t,style:a,children:s})=>{let i=e.height?((e,t)=>{let a=e.includes("top")?1:-1,[s,r]=v()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*a}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*a}%,-1px) scale(.6); opacity:0;}
`];return{animation:t?`${y(s)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${y(r)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||t||"top-center",e.visible):{opacity:0},o=r.createElement(G,{toast:e}),n=r.createElement(K,{...e.ariaProps},h(e.message,e));return r.createElement(J,{className:e.className,style:{...i,...a,...e.style}},"function"==typeof s?s({icon:o,message:n}):r.createElement(r.Fragment,null,o,n))});s=r.createElement,d.p=void 0,m=s,f=void 0,g=void 0;var Q=({id:e,className:t,style:a,onHeightUpdate:s,children:i})=>{let o=r.useCallback(t=>{if(t){let a=()=>{s(e,t.getBoundingClientRect().height)};a(),new MutationObserver(a).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,s]);return r.createElement("div",{ref:o,className:t,style:a},i)},W=p`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;e.s(["Toaster",0,({reverseOrder:e,position:t="top-center",toastOptions:a,gutter:s,children:i,toasterId:o,containerStyle:n,containerClassName:l})=>{let{toasts:d,handlers:c}=((e,t="default")=>{let{toasts:a,pausedAt:s}=((e={},t=w)=>{let[a,s]=(0,r.useState)(A[t]||k),i=(0,r.useRef)(A[t]);(0,r.useEffect)(()=>(i.current!==A[t]&&s(A[t]),N.push([t,s]),()=>{let e=N.findIndex(([e])=>e===t);e>-1&&N.splice(e,1)}),[t]);let o=a.toasts.map(t=>{var a,s,r;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(a=e[t.type])?void 0:a.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(s=e[t.type])?void 0:s.duration)||(null==e?void 0:e.duration)||C[t.type],style:{...e.style,...null==(r=e[t.type])?void 0:r.style,...t.style}}});return{...a,toasts:o}})(e,t),i=(0,r.useRef)(new Map).current,o=(0,r.useCallback)((e,t=O)=>{if(i.has(e))return;let a=setTimeout(()=>{i.delete(e),n({type:4,toastId:e})},t);i.set(e,a)},[]);(0,r.useEffect)(()=>{if(s)return;let e=Date.now(),r=a.map(a=>{if(a.duration===1/0)return;let s=(a.duration||0)+a.pauseDuration-(e-a.createdAt);if(s<0){a.visible&&P.dismiss(a.id);return}return setTimeout(()=>P.dismiss(a.id,t),s)});return()=>{r.forEach(e=>e&&clearTimeout(e))}},[a,s,t]);let n=(0,r.useCallback)($(t),[t]),l=(0,r.useCallback)(()=>{n({type:5,time:Date.now()})},[n]),d=(0,r.useCallback)((e,t)=>{n({type:1,toast:{id:e,height:t}})},[n]),c=(0,r.useCallback)(()=>{s&&n({type:6,time:Date.now()})},[s,n]),u=(0,r.useCallback)((e,t)=>{let{reverseOrder:s=!1,gutter:r=8,defaultPosition:i}=t||{},o=a.filter(t=>(t.position||i)===(e.position||i)&&t.height),n=o.findIndex(t=>t.id===e.id),l=o.filter((e,t)=>t<n&&e.visible).length;return o.filter(e=>e.visible).slice(...s?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+r,0)},[a]);return(0,r.useEffect)(()=>{a.forEach(e=>{if(e.dismissed)o(e.id,e.removeDelay);else{let t=i.get(e.id);t&&(clearTimeout(t),i.delete(e.id))}})},[a,o]),{toasts:a,handlers:{updateHeight:d,startPause:l,endPause:c,calculateOffset:u}}})(a,o);return r.createElement("div",{"data-rht-toaster":o||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...n},className:l,onMouseEnter:c.startPause,onMouseLeave:c.endPause},d.map(a=>{let o,n,l=a.position||t,d=c.calculateOffset(a,{reverseOrder:e,gutter:s,defaultPosition:t}),u=(o=l.includes("top"),n=l.includes("center")?{justifyContent:"center"}:l.includes("right")?{justifyContent:"flex-end"}:{},{left:0,right:0,display:"flex",position:"absolute",transition:v()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${d*(o?1:-1)}px)`,...o?{top:0}:{bottom:0},...n});return r.createElement(Q,{id:a.id,key:a.id,onHeightUpdate:c.updateHeight,className:a.visible?W:"",style:u},"custom"===a.type?h(a.message,a):i?i(a):r.createElement(Y,{toast:a,position:l}))}))},"default",0,P],5766)}]);