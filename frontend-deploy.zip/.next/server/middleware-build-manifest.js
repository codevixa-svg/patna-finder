globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/1kD4DAb6_aU7CUILGJXnb/_buildManifest.js",
    "static/1kD4DAb6_aU7CUILGJXnb/_ssgManifest.js",
    "static/1kD4DAb6_aU7CUILGJXnb/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/227kwhsrjlnp4.js",
    "static/chunks/0zqa8kqwbn54k.js",
    "static/chunks/turbopack-3kolq7252-txz.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
