module.exports=[9647,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_updates_%5Bid%5D_edit_page_actions_1x3lp-p.js.map