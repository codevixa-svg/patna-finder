module.exports=[68938,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_reviews_pending_page_actions_1sibfav.js.map