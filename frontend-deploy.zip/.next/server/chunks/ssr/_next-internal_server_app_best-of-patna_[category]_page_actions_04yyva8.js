module.exports=[5169,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_best-of-patna_%5Bcategory%5D_page_actions_04yyva8.js.map