module.exports=[13964,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_blog_%5Bid%5D_edit_page_actions_1muuosn.js.map