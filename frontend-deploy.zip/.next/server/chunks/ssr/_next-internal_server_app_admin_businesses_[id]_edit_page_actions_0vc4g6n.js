module.exports=[56922,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_businesses_%5Bid%5D_edit_page_actions_0vc4g6n.js.map