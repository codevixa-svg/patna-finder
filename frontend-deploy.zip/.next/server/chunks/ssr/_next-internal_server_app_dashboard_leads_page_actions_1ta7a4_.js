module.exports=[20341,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_leads_page_actions_1ta7a4_.js.map