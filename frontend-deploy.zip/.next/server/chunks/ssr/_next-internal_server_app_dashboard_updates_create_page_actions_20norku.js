module.exports=[18106,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_updates_create_page_actions_20norku.js.map