module.exports=[57680,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_claim-business_page_actions_0wx3__n.js.map