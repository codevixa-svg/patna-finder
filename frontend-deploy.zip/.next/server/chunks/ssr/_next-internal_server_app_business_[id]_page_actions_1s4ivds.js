module.exports=[63290,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_business_%5Bid%5D_page_actions_1s4ivds.js.map