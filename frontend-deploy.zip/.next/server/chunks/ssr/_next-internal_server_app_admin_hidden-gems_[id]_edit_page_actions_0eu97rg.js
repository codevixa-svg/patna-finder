module.exports=[40121,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_hidden-gems_%5Bid%5D_edit_page_actions_0eu97rg.js.map