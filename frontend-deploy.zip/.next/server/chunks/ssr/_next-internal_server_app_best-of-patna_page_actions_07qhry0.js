module.exports=[73736,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_best-of-patna_page_actions_07qhry0.js.map