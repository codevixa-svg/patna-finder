module.exports=[81369,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_add-business_page_actions_0if07ny.js.map