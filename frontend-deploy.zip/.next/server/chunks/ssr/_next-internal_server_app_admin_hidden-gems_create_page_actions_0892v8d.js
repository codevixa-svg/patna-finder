module.exports=[24307,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_hidden-gems_create_page_actions_0892v8d.js.map