module.exports=[98981,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_add-business_page_actions_14gwbwc.js.map