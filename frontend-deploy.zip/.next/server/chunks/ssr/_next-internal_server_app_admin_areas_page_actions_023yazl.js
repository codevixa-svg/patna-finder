module.exports=[12679,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_areas_page_actions_023yazl.js.map