module.exports=[55757,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_register_page_actions_00kh-kl.js.map