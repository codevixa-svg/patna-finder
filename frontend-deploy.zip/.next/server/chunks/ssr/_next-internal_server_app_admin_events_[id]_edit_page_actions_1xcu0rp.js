module.exports=[58672,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_events_%5Bid%5D_edit_page_actions_1xcu0rp.js.map