module.exports=[9176,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_hidden-gems_page_actions_07e-nvg.js.map