module.exports=[79688,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_blog_drafts_page_actions_1x9iqb-.js.map