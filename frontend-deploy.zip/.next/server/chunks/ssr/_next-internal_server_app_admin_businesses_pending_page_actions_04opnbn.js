module.exports=[53073,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_businesses_pending_page_actions_04opnbn.js.map