module.exports=[72020,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_edit-business_page_actions_0abl4a-.js.map