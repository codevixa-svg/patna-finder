const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
// Base URL without the /api/v1 suffix — used to build storage/asset URLs
export const API_BASE_URL = API_URL.replace(/\/api\/v1\/?$/, '');

async function fetchJson(url: string, options?: RequestInit) {
  const res = await fetch(url, options);
  if (!res.ok) {
    const error = await res.json().catch(() => ({ message: 'Request failed' }));
    // Laravel validation errors: { errors: { field: [msg, ...] } }
    const firstValidationMsg = error?.errors
      ? (Object.values(error.errors).flat()[0] as string | undefined)
      : undefined;
    throw new Error(
      firstValidationMsg || error?.message || `Request failed (HTTP ${res.status})`,
    );
  }
  return res.json();
}

export const api = {
  // Categories
  getCategories: async (
    params?: { limit?: number; search?: string },
    options?: RequestInit,
  ) => {
    const queryString = params
      ? `?${new URLSearchParams(params as Record<string, string>)}`
      : '';
    return fetchJson(`${API_URL}/categories${queryString}`, options);
  },

  getCategory: async (slug: string) => {
    return fetchJson(`${API_URL}/categories/${slug}`);
  },

  getCategoryBusinesses: async (slug: string, params?: any) => {
    const queryString = params ? `?${new URLSearchParams(params)}` : '';
    return fetchJson(`${API_URL}/categories/${slug}/businesses${queryString}`);
  },

  // Areas
  getAreas: async () => {
    return fetchJson(`${API_URL}/areas`);
  },

  getArea: async (slug: string) => {
    return fetchJson(`${API_URL}/areas/${slug}`);
  },

  getAreaBusinesses: async (slug: string, params?: any) => {
    const queryString = params ? `?${new URLSearchParams(params)}` : '';
    return fetchJson(`${API_URL}/areas/${slug}/businesses${queryString}`);
  },

  // Businesses
  getBusinesses: async (params?: any) => {
    const queryString = params ? `?${new URLSearchParams(params)}` : '';
    return fetchJson(`${API_URL}/businesses${queryString}`);
  },

  getTrendingBusinesses: async () => {
    return fetchJson(`${API_URL}/businesses/trending`);
  },

  getFeaturedBusinesses: async () => {
    return fetchJson(`${API_URL}/businesses/featured`);
  },

  getHiddenGems: async () => {
    return fetchJson(`${API_URL}/businesses/hidden-gems`);
  },

  getBusiness: async (slug: string) => {
    return fetchJson(`${API_URL}/businesses/${slug}`);
  },

  getNearbyBusinesses: async (slug: string) => {
    return fetchJson(`${API_URL}/businesses/${slug}/nearby`);
  },

  submitBusiness: async (data: any) => {
    return fetchJson(`${API_URL}/businesses`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
  },

  // Reviews
  getLatestReviews: async () => {
    return fetchJson(`${API_URL}/reviews/latest`);
  },

  getReviews: async (slug: string, params?: any) => {
    const queryString = params ? `?${new URLSearchParams(params)}` : '';
    return fetchJson(`${API_URL}/businesses/${slug}/reviews${queryString}`);
  },

  submitReview: async (slug: string, data: any) => {
    return fetchJson(`${API_URL}/businesses/${slug}/reviews`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
  },

  likeReview: async (id: number) => {
    return fetchJson(`${API_URL}/reviews/${id}/like`, { method: 'POST' });
  },

  // Performance tracking (fire-and-forget interaction events)
  trackBusinessEvent: async (slugOrId: string | number, event: string) => {
    return fetch(`${API_URL}/businesses/${slugOrId}/track`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event }),
      keepalive: true,
    }).catch(() => {
      // Tracking must never break the page
    });
  },

  // Blog
  getBlogPosts: async (params?: any) => {
    const queryString = params ? `?${new URLSearchParams(params)}` : '';
    return fetchJson(`${API_URL}/blog${queryString}`);
  },

  // Government Events
  // NOTE: the canonical getEvents / getLatestEvents / getEvent definitions
  // live in the "Events" section below (the earlier duplicates were removed —
  // duplicate object keys made `tsc --noEmit` fail).

  // Blog Categories (public)
  getBlogCategories: async () => {
    return fetchJson(`${API_URL}/blog-categories`);
  },

  getLatestBlogPosts: async () => {
    return fetchJson(`${API_URL}/blog/latest`);
  },

  getBlogPost: async (slug: string) => {
    return fetchJson(`${API_URL}/blog/${slug}`);
  },

  // Search
  search: async (query: string) => {
    return fetchJson(`${API_URL}/search?q=${encodeURIComponent(query)}`);
  },

  getPopularSearches: async () => {
    return fetchJson(`${API_URL}/popular-searches`);
  },

  // Events
  getEvents: async (params?: any) => {
    const queryString = params ? `?${new URLSearchParams(params)}` : '';
    return fetchJson(`${API_URL}/events${queryString}`);
  },

  getEvent: async (slugOrId: string | number) => {
    return fetchJson(`${API_URL}/events/${slugOrId}`);
  },

  getTrendingEvents: async () => {
    return fetchJson(`${API_URL}/events/trending`);
  },

  getFeaturedEvents: async () => {
    return fetchJson(`${API_URL}/events/featured`);
  },

  getPopularEvents: async () => {
    return fetchJson(`${API_URL}/events/popular`);
  },

  getLatestEvents: async () => {
    return fetchJson(`${API_URL}/events/latest`);
  },

  getEventCategories: async () => {
    return fetchJson(`${API_URL}/events/categories`);
  },

  getEventAreas: async () => {
    return fetchJson(`${API_URL}/events/areas`);
  },

  getEventStats: async () => {
    return fetchJson(`${API_URL}/events/stats`);
  },

  markEventInterested: async (id: number) => {
    return fetchJson(`${API_URL}/events/${id}/interested`, { method: 'POST' });
  },

  removeEventInterested: async (id: number) => {
    return fetchJson(`${API_URL}/events/${id}/interested`, { method: 'DELETE' });
  },
};
